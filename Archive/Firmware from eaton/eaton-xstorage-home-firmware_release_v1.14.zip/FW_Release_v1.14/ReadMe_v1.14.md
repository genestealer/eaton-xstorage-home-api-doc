EN

# Release notes
## v1.14
### 00.01.0015-130-g71888818 
#### Inverter firmware 00.04.0066
-------------------------------------------------------------------------------------
Enhancements

Bug fixes and improvements related to Portal Connectivity
Secure Third-Party Components (Local UI)
New Non-Critical Load Calculation Algorithm
Improved xController to Cloud Connection   Algorithm
New Application Firewall
Inverter Temperature will reduce   power output during battery discharge operation 
--------------------------------------------------------------------------------------

FR

# Notes de version
## v1.14
### 00.01.0015-130-g71888818 
#### Firmware de l'onduleur 00.04.0066
-------------------------------------------------------------------------------------
Améliorations

Corrections de bugs et améliorations liées à la connectivité du portail
Sécuriser les composants tiers (UI locale)
Nouvel algorithme de calcul de charge non critique
Amélioration de l'algorithme de connexion xController au cloud
La température de l'onduleur réduira la puissance de sortie pendant l'opération de décharge de la batterie

-------------------------------------------------------------------------------------

IT

# Note di rilascio
## v1.14
### 00.01.0015-130-g71888818
#### Firmware inverter 00.04.0066
-------------------------------------------------------------------------------------
Miglioramenti

Correzioni di bug e miglioramenti relativi alla connettività del portale
Componenti protetti di terze parti (interfaccia utente locale)
Nuovo algoritmo di calcolo del carico non critico
Migliorato l'algoritmo di connessione da xController a Cloud
Nuova applicazione Firewall
La temperatura dell'inverter riduce la potenza erogata durante il funzionamento a scarica della batteria
-------------------------------------------------------------------------------------

DE

# Versionshinweise
## v1.14
### 00.01.0015-130-g71888818
####Wechselrichter-Firmware 00.04.0066
Verbesserungen
-------------------------------------------------------------------------------------
Fehlerbehebungen und Verbesserungen im Zusammenhang mit der Portalkonnektivität
Sichere Komponenten von Drittanbietern (lokale Benutzeroberfläche)
Neuer Algorithmus zur Berechnung unkritischer Lasten
Verbesserter xController-zu-Cloud-Verbindungsalgorithmus
Neue Anwendungsfirewall
Die Wechselrichtertemperatur reduziert die Ausgangsleistung während des Batterieentladevorgangs
-------------------------------------------------------------------------------------